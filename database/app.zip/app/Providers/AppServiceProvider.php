<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        try {
            if (\Illuminate\Support\Facades\Schema::hasTable('general_settings')) {
                $settings = \App\Models\GeneralSetting::first();
                if ($settings) {
                    // Share settings with all views
                    \Illuminate\Support\Facades\View::share('general_settings', $settings);

                    if ($settings->school_name) {
                        \Illuminate\Support\Facades\Config::set('adminlte.title', $settings->school_name);
                        \Illuminate\Support\Facades\Config::set('adminlte.logo', '<b>' . substr($settings->school_name, 0, 16) . '</b>');
                    }
                    if ($settings->logo) {
                        // Use asset() with storage prefix to ensure compatibility
                        \Illuminate\Support\Facades\Config::set('adminlte.logo_img', asset('storage/' . $settings->logo));
                    }
                }
            }
        } catch (\Exception $e) {
            // Ignore DB errors during setup/migration
        }
    }
}
