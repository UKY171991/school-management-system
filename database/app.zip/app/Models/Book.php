<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    protected $fillable = ['school_id', 'title', 'author', 'isbn', 'quantity'];

    public function school()
    {
        return $this->belongsTo(School::class);
    }
}
