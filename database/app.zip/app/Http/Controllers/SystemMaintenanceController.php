<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;

class SystemMaintenanceController extends Controller
{
    /**
     * Clear application cache.
     */
    public function optimize()
    {
        try {
            Artisan::call('optimize:clear');
            return response()->json([
                'success' => 'System cache cleared successfully.',
                'output' => Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Run database migrations.
     */
    public function migrate()
    {
        try {
            Artisan::call('migrate', ['--force' => true]);
            return response()->json([
                'success' => 'Database migrated successfully.',
                'output' => Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Create storage link.
     */
    public function storageLink()
    {
        try {
            Artisan::call('storage:link');
            return response()->json([
                'success' => 'Storage link created successfully.',
                'output' => Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Run composer update.
     */
    public function composerUpdate()
    {
        set_time_limit(600); // Composer update can take time
        try {
            // Find composer path (could be composer or composer.phar)
            $composer = 'composer'; 
            
            // On Windows, sometimes we need to use 'php composer.phar'
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                $check = shell_exec('where composer');
                if (!$check) {
                    $composer = 'php composer.phar';
                }
            }

            $output = shell_exec($composer . ' update --no-interaction 2>&1');
            
            return response()->json([
                'success' => 'Composer update completed.',
                'output' => $output
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
