<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $studentCount = \App\Models\Student::count();
        $teacherCount = \App\Models\Teacher::count();
        $subjectCount = \App\Models\Subject::count();
        $schoolCount = \App\Models\School::count();
        $examCount = \App\Models\Exam::count();
        $bookCount = \App\Models\Book::count();
        $sectionCount = \App\Models\Section::count();
        $hostelCount = \App\Models\Hostel::count();

        $latestStudents = \App\Models\Student::latest()->take(5)->get();
        // Check if created_at exists, if not simpler query might be needed, but assuming standard Laravel timestamps.
        
        return view('dashboard', compact(
            'studentCount', 
            'teacherCount', 
            'subjectCount', 
            'schoolCount', 
            'examCount', 
            'bookCount', 
            'sectionCount', 
            'hostelCount',
            'latestStudents'
        ));
    }
}
