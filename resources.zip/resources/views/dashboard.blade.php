@extends('adminlte::page')

@section('title', __('Dashboard'))

@section('content_header')
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark font-weight-bold">{{ __('Dashboard') }}</h1>
            <p class="text-muted">{{ __('Welcome back to your school management overview.') }}</p>
        </div>
        <div class="col-sm-6 text-right">
             <span class="badge badge-light p-2 shadow-sm border">{{ now()->translatedFormat('l, jS F Y') }}</span>
        </div>
    </div>
@stop

@section('content')
    <!-- Custom Styles for this page -->
    <style>
        .small-box {
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            border: none;
            transition: transform 0.3s ease;
        }
        .small-box:hover {
            transform: translateY(-5px);
        }
        .small-box .icon {
            opacity: 0.2;
            right: 15px;
            top: 15px;
            font-size: 60px;
        }
        .small-box:hover .icon {
            opacity: 0.3;
            font-size: 65px;
        }
        .small-box .inner {
            padding: 20px;
        }
        .small-box h3 {
            font-weight: 700;
            font-size: 2.2rem;
            margin-bottom: 0.2rem;
        }
        .small-box p {
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0;
            opacity: 0.8;
        }
        .card-fancy {
            border-radius: 15px;
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        .card-fancy .card-header {
            background-color: transparent;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 1.25rem 1.5rem;
        }
        .card-fancy .card-title {
            font-weight: 600;
            color: #343a40;
            font-size: 1.1rem;
        }
        .table-custom th {
            border-top: none;
            color: #6c757d;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }
        .table-custom td {
            vertical-align: middle;
            font-size: 0.95rem;
        }
        .avatar-circle {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background-color: #e9ecef;
            color: #495057;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.9rem;
        }

        /* Improved Colors */
        .bg-gradient-info-custom {
            background: linear-gradient(135deg, #117a8b 0%, #17a2b8 100%);
            color: #fff;
        }
        .bg-gradient-success-custom {
            background: linear-gradient(135deg, #1e7e34 0%, #28a745 100%);
            color: #fff;
        }
        .bg-gradient-warning-custom {
            background: linear-gradient(135deg, #d39e00 0%, #ffc107 100%);
            color: #1f2d3d;
        }
        .bg-gradient-danger-custom {
            background: linear-gradient(135deg, #bd2130 0%, #dc3545 100%);
            color: #fff;
        }
        
        
     </style>

    @if(auth()->user()->isMasterAdmin())
    <div class="row mb-4">
        <div class="col-12">
            <div class="card card-fancy shadow-sm border-0" style="background: #f8f9fa;">
                <div class="card-body p-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap">
                        <div class="d-flex align-items-center mb-2 mb-md-0">
                            <div class="bg-primary p-2 rounded mr-3">
                                <i class="fas fa-tools text-white"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 font-weight-bold">{{ __('System Maintenance') }}</h6>
                                <p class="mb-0 text-muted small">{{ __('Quick actions for Master Administrator') }}</p>
                            </div>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <button class="btn btn-sm btn-info maintenance-btn mr-2" data-action="optimize">
                                <i class="fas fa-broom mr-1"></i> {{ __('Clear Cache') }}
                            </button>
                            <button class="btn btn-sm btn-success maintenance-btn mr-2" data-action="migrate">
                                <i class="fas fa-database mr-1"></i> {{ __('Migrate DB') }}
                            </button>
                            <button class="btn btn-sm btn-warning maintenance-btn mr-2" data-action="storage-link">
                                <i class="fas fa-link mr-1"></i> {{ __('Storage Link') }}
                            </button>
                            <button class="btn btn-sm btn-dark maintenance-btn" data-action="composer-update">
                                <i class="fas fa-terminal mr-1"></i> {{ __('Composer Update') }}
                            </button>
                        </div>
                    </div>
                    <div id="maintenanceOutput" class="mt-3 p-2 bg-dark text-light rounded d-none" style="max-height: 150px; overflow-y: auto;">
                        <pre class="m-0 text-light small" id="outputText"></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-gradient-info-custom">
                <div class="inner">
                    <h3>{{ $studentCount }}</h3>
                    <p>{{ __('Total Students') }}</p>
                </div>
                <div class="icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <a href="{{ route('admissions.index') }}" class="small-box-footer">{{ __('More info') }} <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-gradient-success-custom">
                <div class="inner">
                    <h3>{{ $teacherCount }}</h3>
                    <p>{{ __('Teachers') }}</p>
                </div>
                <div class="icon">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <a href="{{ route('teacher-profiles.index') }}" class="small-box-footer">{{ __('More info') }} <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-gradient-warning-custom">
                <div class="inner">
                    <h3>{{ $examCount }}</h3>
                    <p>{{ __('Exams') }}</p>
                </div>
                <div class="icon">
                    <i class="fas fa-clipboard-list"></i>
                </div>
                <a href="{{ route('exams.index') }}" class="small-box-footer" style="color: inherit;">{{ __('More info') }} <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-gradient-danger-custom">
                <div class="inner">
                    <h3>{{ $schoolCount }}</h3>
                    <p>{{ __('Schools') }}</p>
                </div>
                <div class="icon">
                    <i class="fas fa-school"></i>
                </div>
                <a href="{{ route('schools.index') }}" class="small-box-footer">{{ __('More info') }} <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Left Column -->
        <div class="col-lg-8">
            <!-- Analytics Chart -->
            <div class="card card-fancy">
                <div class="card-header d-flex justify-content-between">
                    <h3 class="card-title"><i class="fas fa-chart-pie mr-1"></i> {{ __('Data Overview') }}</h3>
                </div>
                <div class="card-body">
                    <canvas id="overviewChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
            </div>

            <!-- Recent Students -->
            <div class="card card-fancy">
                <div class="card-header border-0">
                    <h3 class="card-title"><i class="fas fa-users mr-1"></i> {{ __('Recently Admitted Students') }}</h3>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped table-valign-middle table-custom mb-0">
                            <thead>
                            <tr>
                                <th>{{ __('Name') }}</th>
                                <th>{{ __('Email') }}</th>
                                <th>{{ __('Class') }}</th>
                                <th class="text-right">{{ __('Action') }}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if(isset($latestStudents) && $latestStudents->count() > 0)
                                @foreach($latestStudents as $student)
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle mr-2">
                                                {{ strtoupper(substr($student->name, 0, 1)) }}
                                            </div>
                                            <span class="font-weight-bold">{{ $student->name }}</span>
                                        </div>
                                    </td>
                                    <td>{{ $student->email }}</td>
                                    <td>
                                        <span class="badge badge-info text-white px-2 py-1">
                                            {{ $student->grade ? $student->grade->name : 'N/A' }} 
                                            {{ $student->section ? ' - ' . $student->section->name : '' }}
                                        </span>
                                    </td>
                                    <td class="text-right">
                                        <a href="{{ route('student-profiles.index', ['search' => $student->roll_number]) }}" class="btn btn-sm btn-outline-primary" title="{{ __('View Profile') }}">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                             @else
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">{{ __('No recent students found.') }}</td>
                                </tr>
                            @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column -->
        <div class="col-lg-4">
            
            <!-- Quick Actions -->
            <div class="card card-fancy bg-light">
                <div class="card-header">
                    <h3 class="card-title text-primary"><i class="fas fa-bolt mr-1"></i> {{ __('Quick Actions') }}</h3>
                </div>
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <a href="{{ route('admissions.index') }}" class="btn btn-primary btn-block text-left mb-2 shadow-sm rounded-pill">
                            <i class="fas fa-plus-circle mr-2"></i> {{ __('Add Student') }}
                        </a>
                        <a href="{{ route('teacher-profiles.index') }}" class="btn btn-success btn-block text-left mb-2 shadow-sm rounded-pill">
                            <i class="fas fa-user-tie mr-2"></i> {{ __('Add Teacher') }}
                        </a>
                        <a href="{{ route('exams.index') }}" class="btn btn-warning text-white btn-block text-left mb-2 shadow-sm rounded-pill">
                            <i class="fas fa-calendar-check mr-2"></i> {{ __('Schedule Exam') }}
                        </a>
                          @if(Route::has('fee-payments.index'))
                         <a href="{{ route('fee-payments.index') }}" class="btn btn-info btn-block text-left shadow-sm rounded-pill">
                            <i class="fas fa-file-invoice-dollar mr-2"></i> {{ __('Collect Fees') }}
                        </a>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Other Stats -->
            <div class="info-box mb-3 bg-white shadow-sm rounded" style="padding: 1rem;">
                <span class="info-box-icon bg-indigo elevation-1 rounded-circle"><i class="fas fa-copy"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">{{ __('Subjects') }}</span>
                    <span class="info-box-number text-lg">{{ $subjectCount }}</span>
                </div>
            </div>
            
              <div class="info-box mb-3 bg-white shadow-sm rounded" style="padding: 1rem;">
                <span class="info-box-icon bg-fuchsia elevation-1 rounded-circle"><i class="fas fa-layer-group"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">{{ __('Sections') }}</span>
                    <span class="info-box-number text-lg">{{ $sectionCount }}</span>
                </div>
            </div>

             <div class="info-box mb-3 bg-white shadow-sm rounded" style="padding: 1rem;">
                <span class="info-box-icon bg-primary elevation-1 rounded-circle"><i class="fas fa-book"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">{{ __('Library Books') }}</span>
                    <span class="info-box-number text-lg">{{ $bookCount }}</span>
                </div>
            </div>

            <div class="info-box mb-3 bg-white shadow-sm rounded" style="padding: 1rem;">
                <span class="info-box-icon bg-teal elevation-1 rounded-circle"><i class="fas fa-building"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">{{ __('Hostels') }}</span>
                    <span class="info-box-number text-lg">{{ $hostelCount }}</span>
                </div>
            </div>

        </div>
    </div>
@stop

@section('js')
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('overviewChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ["{{ __('Students') }}", "{{ __('Teachers') }}", "{{ __('Exams') }}", "{{ __('Schools') }}", "{{ __('Hostels') }}"],
                    datasets: [{
                        label: "{{ __('Total Count') }}",
                        data: [
                            {{ $studentCount }}, 
                            {{ $teacherCount }}, 
                            {{ $examCount }}, 
                            {{ $schoolCount }},
                            {{ $hostelCount }}
                        ],
                        backgroundColor: [
                            'rgba(23, 162, 184, 0.7)',
                            'rgba(40, 167, 69, 0.7)',
                            'rgba(255, 193, 7, 0.7)',
                            'rgba(220, 53, 69, 0.7)',
                            'rgba(32, 201, 151, 0.7)'
                        ],
                        borderColor: [
                            'rgba(23, 162, 184, 1)',
                            'rgba(40, 167, 69, 1)',
                            'rgba(255, 193, 7, 1)',
                            'rgba(220, 53, 69, 1)',
                            'rgba(32, 201, 151, 1)'
                        ],
                        borderWidth: 1,
                        borderRadius: 5,
                        barPercentage: 0.6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        title: {
                            display: true,
                            text: '{{ __("Resource Distribution") }}',
                            font: { size: 14 }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                borderDash: [2, 2]
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        // Handle Maintenance Actions
        $('.maintenance-btn').click(function() {
            let action = $(this).data('action');
            let btn = $(this);
            let originalText = btn.html();
            
            Swal.fire({
                title: '{{ __("Are you sure?") }}',
                text: '{{ __("Running operation") }}: ' + action.replace('-', ' '),
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '{{ __("Yes, proceed!") }}'
            }).then((result) => {
                if (result.isConfirmed) {
                    btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i> {{ __("Processing...") }}');
                    $('#maintenanceOutput').addClass('d-none');

                    $.ajax({
                        url: `/admin/maintenance/${action}`,
                        type: "POST",
                        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                        success: function(response) {
                            btn.prop('disabled', false).html(originalText);
                            Swal.fire('{{ __("Success") }}', response.success, 'success');
                            if (response.output) {
                                $('#maintenanceOutput').removeClass('d-none');
                                $('#outputText').text(response.output);
                            }
                        },
                        error: function(xhr) {
                            btn.prop('disabled', false).html(originalText);
                            let errorMsg = xhr.responseJSON ? (xhr.responseJSON.error || xhr.responseJSON.message) : '{{ __("Something went wrong") }}';
                            Swal.fire('{{ __("Error") }}', errorMsg, 'error');
                        }
                    });
                }
            });
        });
    });
</script>
@stop
