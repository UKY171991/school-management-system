@extends('adminlte::page')

@section('title', __('Schools'))

@section('content_header')
    <h1>{{ __('Schools Management') }}</h1>
@stop

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title">{{ __('List of Schools') }}</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-primary btn-sm" id="createNewSchool">
                        <i class="fas fa-plus"></i> {{ __('Add New School') }}
                    </button>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped" id="schoolsTable">
                    <thead>
                        <tr>
                            <th>{{ __('ID') }}</th>
                            <th>{{ __('Logo') }}</th>
                            @if(auth()->user()->isMasterAdmin())
                            <th>{{ __('Admin Name') }}</th>
                            @endif
                            <th>{{ __('Name') }}</th>
                            <th>{{ __('Address') }}</th>
                            <th>{{ __('Phone') }}</th>
                            <th>{{ __('Email') }}</th>
                            <th>{{ __('Signature') }}</th>
                            <th width="150">{{ __('Actions') }}</th>
                        </tr>
                    </thead>
                    <tbody id="schoolList">
                        <!-- Loaded via AJAX -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- School Modal -->
<div class="modal fade" id="schoolModal" tabindex="-1" role="dialog" aria-labelledby="schoolModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="schoolForm" name="schoolForm" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="schoolModalLabel">{{ __('Add School') }}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="{{ __('Close') }}">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="school_id" id="school_id">
                    <div class="form-group">
                        <label for="name">{{ __('Name') }}</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    @if(auth()->user()->isMasterAdmin())
                    <div class="form-group">
                        <label for="admin_id">{{ __('Assign Admin') }}</label>
                        <select class="form-control select2" id="admin_id" name="admin_id" style="width: 100%;">
                            <option value="">{{ __('Choose Admin...') }}</option>
                            @foreach($admins as $admin)
                                <option value="{{ $admin->id }}">{{ $admin->name }}</option>
                            @endforeach
                        </select>
                        <small class="text-muted">{{ __('Only admins without a school or currently assigned to this school are shown.') }}</small>
                    </div>
                    @endif
                    <div class="form-group">
                        <label for="address">{{ __('Address') }}</label>
                        <input type="text" class="form-control" id="address" name="address">
                    </div>
                    <div class="form-group">
                        <label for="phone">{{ __('Phone') }}</label>
                        <input type="text" class="form-control" id="phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="email">{{ __('Email') }}</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="logo">{{ __('School Logo') }}</label>
                        <input type="file" class="form-control" id="logo" name="logo">
                        <div id="logo-preview" class="mt-2"></div>
                    </div>
                    <div class="form-group">
                        <label for="principal_signature">{{ __('Principal Signature') }}</label>
                        <input type="file" class="form-control" id="principal_signature" name="principal_signature">
                        <div id="signature-preview" class="mt-2"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Close') }}</button>
                    <button type="submit" class="btn btn-primary" id="saveBtn">{{ __('Save') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View School Modal -->
<div class="modal fade" id="viewSchoolModal" tabindex="-1" role="dialog" aria-labelledby="viewSchoolModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewSchoolModalLabel">{{ __('View School Details') }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="{{ __('Close') }}">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <tr>
                        <th style="width: 30%">{{ __('Name') }}</th>
                        <td id="view_name"></td>
                    </tr>
                    <tr>
                        <th>{{ __('Address') }}</th>
                        <td id="view_address"></td>
                    </tr>
                    <tr>
                        <th>{{ __('Phone') }}</th>
                        <td id="view_phone"></td>
                    </tr>
                    <tr>
                        <th>{{ __('Email') }}</th>
                        <td id="view_email"></td>
                    </tr>
                    <tr>
                        <th>{{ __('Logo') }}</th>
                        <td id="view_logo"></td>
                    </tr>
                    <tr>
                        <th>{{ __('Signature') }}</th>
                        <td id="view_signature"></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Close') }}</button>
            </div>
        </div>
    </div>
</div>

@stop

@section('js')
<script>
    $(function () {
        // Initialize Select2
        $('.select2').select2({ theme: 'bootstrap4' });

        // CSRF Token Setup
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Load Schools
        function loadSchools() {
            $.get("{{ route('schools.index') }}", function (data) {
                let rows = '';
                data.forEach(school => {
                    let logo = school.logo_url ? `<img src="${school.logo_url}" width="50" class="img-thumbnail">` : "{{ __('No Logo') }}";
                    let signature = school.signature_url ? `<img src="${school.signature_url}" width="50" class="img-thumbnail">` : "{{ __('No Signature') }}";
                    let adminName = school.admin ? `<span class="badge badge-info">${school.admin.name}</span>` : `<span class="text-muted">{{ __('Not Assigned') }}</span>`;
                    
                    rows += `
                        <tr id="school_${school.id}">
                            <td>${school.id}</td>
                            <td>${logo}</td>
                            @if(auth()->user()->isMasterAdmin())
                            <td>${adminName}</td>
                            @endif
                            <td>${school.name}</td>
                            <td>${school.address || ''}</td>
                            <td>${school.phone || ''}</td>
                            <td>${school.email || ''}</td>
                            <td>${signature}</td>
                            <td>
                                <button class="btn btn-info btn-sm viewSchool" data-id="${school.id}" title="{{ __('View') }}">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-warning btn-sm editSchool" data-id="${school.id}" title="{{ __('Edit') }}">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-danger btn-sm deleteSchool" data-id="${school.id}" title="{{ __('Delete') }}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
                $('#schoolList').html(rows);
            });
        }

        loadSchools();

        // Open Create Modal
        $('#createNewSchool').click(function () {
            $('#schoolForm').trigger("reset");
            $('#schoolModalLabel').html("{{ __('Add New School') }}");
            $('#school_id').val('');
            @if(auth()->user()->isMasterAdmin())
                $('#admin_id').val('').trigger('change');
            @endif
            $('#logo-preview, #signature-preview').empty();
            $('#schoolModal').modal('show');
        });

// Save School (Create/Update)
        $('#schoolForm').submit(function (e) {
            e.preventDefault();
            let id = $('#school_id').val();
            let url = id ? `/admin/schools/${id}` : "{{ route('schools.store') }}";
            
            // For Laravel to handle PUT with files, we use POST and _method=PUT
            let formData = new FormData(this);
            if (id) {
                formData.append('_method', 'PUT');
            }

            $.ajax({
                data: formData,
                url: url,
                type: "POST", // Always POST for file uploads, Laravel handles spoofing if needed
                contentType: false,
                processData: false,
                success: function (data) {
                    $('#schoolForm').trigger("reset");
                    $('#schoolModal').modal('hide');
                    loadSchools();
                    Swal.fire("{{ __('Success') }}", data.success, 'success');
                },
                error: function (data) {
                    console.log('Error:', data);
                    let errors = data.responseJSON.errors;
                    let errorMsg = '';
                    $.each(errors, function(key, value) {
                        errorMsg += value + '<br>';
                    });
                    Swal.fire("{{ __('Error') }}", errorMsg, 'error');
                }
            });
        });

        // Edit School
        $('body').on('click', '.editSchool', function () {
            let id = $(this).data('id');
            $.get(`/admin/schools/${id}`, function (data) {
                $('#schoolModalLabel').html("{{ __('Edit School') }}");
                $('#school_id').val(data.id);
                $('#name').val(data.name);
                $('#address').val(data.address);
                $('#phone').val(data.phone);
                $('#email').val(data.email);
                
                @if(auth()->user()->isMasterAdmin())
                    if (data.admin) {
                        $('#admin_id').val(data.admin.id).trigger('change');
                    } else {
                        $('#admin_id').val('').trigger('change');
                    }
                @endif
                
                if (data.logo_url) {
                    $('#logo-preview').html(`
                        <div class="position-relative d-inline-block">
                            <img src="${data.logo_url}" width="100" class="img-thumbnail">
                            <button type="button" class="btn btn-danger btn-xs delete-asset" data-id="${data.id}" data-type="logo" style="position:absolute; top: -5px; right: -5px;">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    `);
                } else {
                    $('#logo-preview').empty();
                }

                if (data.signature_url) {
                    $('#signature-preview').html(`
                        <div class="position-relative d-inline-block">
                            <img src="${data.signature_url}" width="100" class="img-thumbnail">
                            <button type="button" class="btn btn-danger btn-xs delete-asset" data-id="${data.id}" data-type="principal_signature" style="position:absolute; top: -5px; right: -5px;">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    `);
                } else {
                    $('#signature-preview').empty();
                }
                
                $('#schoolModal').modal('show');
            });
        });

        // View School
        $('body').on('click', '.viewSchool', function () {
            let id = $(this).data('id');
            $.get(`/admin/schools/${id}`, function (data) {
                $('#view_name').text(data.name);
                $('#view_address').text(data.address || 'N/A');
                $('#view_phone').text(data.phone || 'N/A');
                $('#view_email').text(data.email || 'N/A');

                if (data.logo_url) {
                    $('#view_logo').html(`<img src="${data.logo_url}" width="100" class="img-thumbnail">`);
                } else {
                    $('#view_logo').text("{{ __('No Logo') }}");
                }

                if (data.signature_url) {
                    $('#view_signature').html(`<img src="${data.signature_url}" width="100" class="img-thumbnail">`);
                } else {
                    $('#view_signature').text("{{ __('No Signature') }}");
                }

                $('#viewSchoolModal').modal('show');
            });
        });

        // Delete School
        $('body').on('click', '.deleteSchool', function () {
            let id = $(this).data('id');
            if (confirm("{{ __('Are you sure you want to delete this school?') }}")) {
                $.ajax({
                    type: "DELETE",
                    url: `/admin/schools/${id}`,
                    success: function (data) {
                        $(`#school_${id}`).remove();
                        Swal.fire("{{ __('Deleted') }}", data.success, 'success');
                    },
                    error: function (data) {
                        console.log('Error:', data);
                    }
                });
            }
        });
        
        // Delete Asset (Logo/Signature)
        $('body').on('click', '.delete-asset', function () {
            let id = $(this).data('id');
            let type = $(this).data('type');
            let container = $(this).closest('.form-group').find('.mt-2');

            if (confirm("{{ __('Are you sure?') }}")) {
                $.ajax({
                    type: "DELETE",
                    url: `/admin/schools/${id}/delete-asset`,
                    data: { type: type },
                    success: function (data) {
                        container.empty();
                        loadSchools();
                        Swal.fire("{{ __('Deleted') }}", data.success, 'success');
                    },
                    error: function (data) {
                        console.log('Error:', data);
                        Swal.fire("{{ __('Error') }}", "{{ __('Failed to delete asset') }}", 'error');
                    }
                });
            }
        });
    });
</script>
@stop
